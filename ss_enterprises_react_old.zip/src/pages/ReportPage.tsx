export default function Report() {
  return (
    <div>
      <h1>Report</h1>
    </div>
  );
}
