export default function Settings() {
  return (
    <div>
      <h1>Setting</h1>
    </div>
  );
}
